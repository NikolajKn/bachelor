export const ItemTypes = {
    TODO : "todo"
}